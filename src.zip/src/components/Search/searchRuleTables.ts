// Shared search rule tables for SearchBar and Navigation search inputs.
// Keep ONLY one copy of blacklist/priority maintenance.

import type { FeatureRecord } from '@/components/Rules/renderRules';

// ===== Rule blacklist =====
// One rule per line; supported fields: Class / Kind / SKind / SKind2.
// - Only Class: blacklist all of that Class
// - With Kind/SKind/SKind2: must all match
export const SEARCH_RULE_BLACKLIST_LINES: string[] = [
  '"Class":"PFB"',
];

// ===== Rule priority =====
// Order is priority (smaller index = higher).
export const SEARCH_RULE_PRIORITY_LINES: string[] = [
  '"Class":"STB"',
  '"Class":"BUD"',
  // Add more rules if needed.
];

export type RuleTableItem = {
  Class?: string;
  Kind?: string;
  SKind?: string;
  SKind2?: string;
};

const parseRuleLines = (lines: string[]): RuleTableItem[] => {
  const out: RuleTableItem[] = [];
  for (const raw of lines) {
    const s = String(raw ?? '').trim();
    if (!s || s.startsWith('//') || s.startsWith('#')) continue;
    const re = /"(Class|Kind|SKind|SKind2)"\s*:\s*"([^"]*)"/g;
    const item: RuleTableItem = {};
    let m: RegExpExecArray | null;
    while ((m = re.exec(s))) {
      const k = m[1] as keyof RuleTableItem;
      const v = String(m[2] ?? '').trim();
      if (v) (item as any)[k] = v;
    }
    if (item.Class || item.Kind || item.SKind || item.SKind2) out.push(item);
  }
  return out;
};

const SEARCH_RULE_BLACKLIST = parseRuleLines(SEARCH_RULE_BLACKLIST_LINES);
const SEARCH_RULE_PRIORITY = parseRuleLines(SEARCH_RULE_PRIORITY_LINES);

/**
 * Extract Kind/SKind/SKind2 triplet with the same compatibility logic as SearchBar.
 * - BUD: BuildingKind/BuildingSKind
 * - FLR/STF: FloorKind/FloorSKind
 * - Otherwise: Point/PLine/PGon* fields based on geometry type, falling back to Kind/SKind/SKind2.
 */
export function extractKindTriplet(r: FeatureRecord): { kind: string; skind: string; skind2: string } {
  const fi: any = r?.featureInfo ?? {};
  const tags: any = fi?.tags ?? fi?.Tags ?? {};
  const cls = String(r?.meta?.Class ?? fi?.Class ?? '').trim();

  if (cls === 'BUD') {
    return {
      kind: String(fi.BuildingKind ?? tags.BuildingKind ?? fi.Kind ?? tags.Kind ?? '').trim(),
      skind: String(fi.BuildingSKind ?? tags.BuildingSKind ?? fi.SKind ?? tags.SKind ?? '').trim(),
      skind2: String(fi.SKind2 ?? tags.SKind2 ?? '').trim(),
    };
  }
  if (cls === 'FLR' || cls === 'STF') {
    return {
      kind: String(fi.FloorKind ?? tags.FloorKind ?? fi.Kind ?? tags.Kind ?? '').trim(),
      skind: String(fi.FloorSKind ?? tags.FloorSKind ?? fi.SKind ?? tags.SKind ?? '').trim(),
      skind2: String(fi.SKind2 ?? tags.SKind2 ?? '').trim(),
    };
  }

  const t = (r as any)?.type ?? (r as any)?.meta?.Type;
  const prefix = t === 'Points' ? 'Point' : t === 'Polyline' ? 'PLine' : t === 'Polygon' ? 'PGon' : '';
  if (prefix) {
    const kKey = `${prefix}Kind`;
    const skKey = `${prefix}SKind`;
    const sk2Key = `${prefix}SKind2`;
    return {
      kind: String(fi?.[kKey] ?? tags?.[kKey] ?? fi.Kind ?? tags.Kind ?? '').trim(),
      skind: String(fi?.[skKey] ?? tags?.[skKey] ?? fi.SKind ?? tags.SKind ?? '').trim(),
      skind2: String(fi?.[sk2Key] ?? tags?.[sk2Key] ?? fi.SKind2 ?? tags.SKind2 ?? '').trim(),
    };
  }

  return {
    kind: String(fi.Kind ?? tags.Kind ?? '').trim(),
    skind: String(fi.SKind ?? tags.SKind ?? '').trim(),
    skind2: String(fi.SKind2 ?? tags.SKind2 ?? '').trim(),
  };
}

export function isRuleBlacklisted(r: FeatureRecord): boolean {
  if (!SEARCH_RULE_BLACKLIST.length) return false;
  const fi: any = r?.featureInfo ?? {};
  const cls = String(r?.meta?.Class ?? fi?.Class ?? '').trim();
  const kk = extractKindTriplet(r);
  for (const it of SEARCH_RULE_BLACKLIST) {
    if (it.Class && it.Class !== cls) continue;
    if (it.Kind && it.Kind !== kk.kind) continue;
    if (it.SKind && it.SKind !== kk.skind) continue;
    if (it.SKind2 && it.SKind2 !== kk.skind2) continue;
    return true;
  }
  return false;
}

export function getRulePriorityIndex(r: FeatureRecord): number {
  if (!SEARCH_RULE_PRIORITY.length) return Number.POSITIVE_INFINITY;
  const fi: any = r?.featureInfo ?? {};
  const cls = String(r?.meta?.Class ?? fi?.Class ?? '').trim();
  const kk = extractKindTriplet(r);
  for (let i = 0; i < SEARCH_RULE_PRIORITY.length; i++) {
    const it = SEARCH_RULE_PRIORITY[i];
    if (it.Class && it.Class !== cls) continue;
    if (it.Kind && it.Kind !== kk.kind) continue;
    if (it.SKind && it.SKind !== kk.skind) continue;
    if (it.SKind2 && it.SKind2 !== kk.skind2) continue;
    return i;
  }
  return Number.POSITIVE_INFINITY;
}
