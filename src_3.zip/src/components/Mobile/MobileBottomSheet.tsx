import AppButton from '@/components/ui/AppButton';
import AppCard from '@/components/ui/AppCard';
import { ChevronDown, ChevronUp, X } from 'lucide-react';
import type { ReactNode } from 'react';

interface MobileBottomSheetProps {
  open: boolean;
  collapsed?: boolean;
  title?: string;
  onClose: () => void;
  onToggleCollapsed?: () => void;
  children: ReactNode;
}

export default function MobileBottomSheet({
  open,
  collapsed = false,
  title,
  onClose,
  onToggleCollapsed,
  children,
}: MobileBottomSheetProps) {
  if (!open) return null;

  return (
    <div className="sm:hidden absolute inset-x-2 bottom-2 z-[1002] pointer-events-none">
      <AppCard className="pointer-events-auto bg-white/95 backdrop-blur-sm rounded-[28px] shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-4 pt-3 pb-2 border-b border-gray-100">
          <AppButton
            onClick={onToggleCollapsed}
            className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800 rounded-full px-1.5 py-1"
            title={collapsed ? '展开面板' : '收起面板'}
          >
            <span className="block w-10 h-1 rounded-full bg-gray-300" />
            {title ? <span className="font-medium">{title}</span> : null}
            {onToggleCollapsed ? (collapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />) : null}
          </AppButton>
          <AppButton
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full"
            title="关闭"
          >
            <X className="w-4 h-4" />
          </AppButton>
        </div>

        {!collapsed ? (
          <div className="max-h-[58vh] overflow-y-auto p-2 pb-4">
            {children}
          </div>
        ) : null}
      </AppCard>
    </div>
  );
}
