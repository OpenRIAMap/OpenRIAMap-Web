/**
 * 世界切换器组件
 * 使用标签页样式在不同世界之间切换
 */

import { Globe } from 'lucide-react';
import AppButton from '@/components/ui/AppButton';

interface World {
  id: string;
  name: string;
  center: { x: number; y: number; z: number };
}

interface WorldSwitcherProps {
  worlds: World[];
  currentWorld: string;
  onWorldChange: (worldId: string) => void;
  mobile?: boolean;
}

export function WorldSwitcher({
  worlds,
  currentWorld,
  onWorldChange,
  mobile = false,
}: WorldSwitcherProps) {
  return (
    <div className={`mt-2 flex items-center gap-1 overflow-x-auto ${mobile ? 'pb-1' : ''}`}>
      <Globe className={`${mobile ? 'w-3.5 h-3.5' : 'w-4 h-4'} text-gray-400 mr-1 flex-shrink-0`} />
      {worlds.map(world => (
        <AppButton
          key={world.id}
          onClick={() => onWorldChange(world.id)}
          className={`flex-shrink-0 ${mobile ? 'px-2.5 py-1 text-[11px]' : 'px-3 py-1 text-xs'} font-medium rounded-full transition-all ${
            world.id === currentWorld
              ? 'bg-blue-500 text-white shadow-sm'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          {world.name}
        </AppButton>
      ))}
    </div>
  );
}

export default WorldSwitcher;