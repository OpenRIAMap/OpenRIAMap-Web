import type { ReactNode } from 'react';

import AppCard from '@/components/ui/AppCard';

interface MobileQuickPanelProps {
  anchorTop: number;
  anchorHeight: number;
  direction?: 'down' | 'up';
  children: ReactNode;
}

export default function MobileQuickPanel({
  anchorTop,
  anchorHeight,
  direction = 'down',
  children,
}: MobileQuickPanelProps) {
  const top = direction === 'down' ? anchorTop : Math.max(0, anchorTop + anchorHeight - 148);

  return (
    <div
      className="absolute right-full mr-3 w-[min(248px,calc(100vw-96px))] pointer-events-auto"
      style={{ top }}
    >
      <AppCard className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-black/5 p-2.5 overflow-hidden max-h-[220px]">
        <div className="max-h-[200px] overflow-y-auto">
          {children}
        </div>
      </AppCard>
    </div>
  );
}
